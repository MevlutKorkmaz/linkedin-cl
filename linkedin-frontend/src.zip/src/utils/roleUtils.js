// ✅ utils/roleUtils.js

export const isAdmin = (role) => role === 'ADMIN';
export const isUser = (role) => role === 'USER';
export const isCompany = (role) => role === 'COMPANY';

