import { useEffect, useState } from "react";
import {
  getUserConnections,
  respondToConnectionRequest,
  deleteConnection,
} from "../api/connectionApi";
import ConnectionCard from "../components/ConnectionCard";
import MainLayout from "../components/layout/MainLayout";
import {
  Typography,
  Box,
  CircularProgress,
  Snackbar,
  Alert,
  ToggleButtonGroup,
  ToggleButton,
} from "@mui/material";

export default function Connections() {
  const userId = localStorage.getItem("userId");
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, message: "", error: false });
  const [filter, setFilter] = useState("ALL");

  const loadConnections = async () => {
    try {
      const res = await getUserConnections(userId);
      setConnections(res.data);
    } catch (err) {
      setSnackbar({ open: true, message: err.message || "Failed to load connections", error: true });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConnections();
  }, []);

  const handleAccept = async (id) => {
    try {
      await respondToConnectionRequest(id, true);
      setConnections(prev =>
        prev.map(c => c.id === id ? { ...c, status: "ACCEPTED", respondedAt: new Date().toISOString() } : c)
      );
      setSnackbar({ open: true, message: "Connection accepted", error: false });
    } catch (err) {
      setSnackbar({ open: true, message: err.message || "Failed to accept", error: true });
    }
  };

  const handleReject = async (id) => {
    try {
      await respondToConnectionRequest(id, false);
      setConnections(prev =>
        prev.map(c => c.id === id ? { ...c, status: "REJECTED", respondedAt: new Date().toISOString() } : c)
      );
      setSnackbar({ open: true, message: "Connection rejected", error: false });
    } catch (err) {
      setSnackbar({ open: true, message: err.message || "Failed to reject", error: true });
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteConnection(id);
      setConnections(prev => prev.filter(c => c.id !== id));
      setSnackbar({ open: true, message: "Connection removed", error: false });
    } catch (err) {
      setSnackbar({ open: true, message: err.message || "Failed to delete", error: true });
    }
  };

  const filtered = connections.filter((c) => {
    if (filter === "ALL") return true;
    if (filter === "ACCEPTED") return c.status === "ACCEPTED";
    if (filter === "PENDING") return c.status === "PENDING";
    if (filter === "INCOMING") return c.status === "PENDING" && c.receiverId === userId;
    if (filter === "OUTGOING") return c.status === "PENDING" && c.requesterId === userId;
    return false;
  });

  return (
    <MainLayout>
      <Box sx={{ maxWidth: 800, mx: "auto", mt: 4 }}>
        <Typography variant="h4" gutterBottom>🔗 My Connections</Typography>

        <ToggleButtonGroup
          value={filter}
          exclusive
          onChange={(e, val) => val && setFilter(val)}
          sx={{ mb: 3 }}
        >
          <ToggleButton value="ALL">All</ToggleButton>
          <ToggleButton value="ACCEPTED">Accepted</ToggleButton>
          <ToggleButton value="PENDING">Pending</ToggleButton>
          <ToggleButton value="INCOMING">Incoming</ToggleButton>
          <ToggleButton value="OUTGOING">Outgoing</ToggleButton>
        </ToggleButtonGroup>

        {loading ? (
          <Box display="flex" justifyContent="center" mt={4}>
            <CircularProgress />
          </Box>
        ) : filtered.length === 0 ? (
          <Typography>No connections found.</Typography>
        ) : (
          filtered.map(conn => (
            <ConnectionCard
              key={conn.id}
              connection={conn}
              onAccept={conn.status === "PENDING" && conn.receiverId === userId ? handleAccept : null}
              onReject={conn.status === "PENDING" && conn.receiverId === userId ? handleReject : null}
              onDelete={handleDelete}
            />
          ))
        )}

        <Snackbar
          open={snackbar.open}
          autoHideDuration={3000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          <Alert severity={snackbar.error ? "error" : "success"} sx={{ width: "100%" }}>
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Box>
    </MainLayout>
  );
}
