package com.linkedin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedinApplicationTests {

	@Test
	void contextLoads() {
	}

}
